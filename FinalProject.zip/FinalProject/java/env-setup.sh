export CLASSPATH=.:.weka.jar
