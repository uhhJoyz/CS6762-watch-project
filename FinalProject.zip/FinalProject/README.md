Note: after processing the files in door_data into their corresponding features files, you need to drag and drop them into the processed_door_data folder.

Additionally, there was not any official project file setup for the java files (because none of us are aware of any standard project setup), so the java must be executed on the terminal with the java command and WEKA must be added to the classpath (jar included). The env-setup.sh script worked for some of us in the group, but not others.

Our final results can be viewed in the java/results.txt file, which is just the console output of each of our classification tests.